// write a javascirpt code printFibonacciSequence
function printFibonacciSequence(n) {
  var fibSeq = [0, 1]; 
  for (var i = 2; i < n; i++) {
    var nextNum = fibSeq[i - 1] + fibSeq[i - 2]; // Calculate the next number in the sequence
    fibSeq.push(nextNum); // Add the next number to the sequence
  }
   for (var i = 0; i < fibSeq.length; i++) {
    console.log(fibSeq[i]);  }}
var numTerms = 10; 
printFibonacciSequence(numTerms);

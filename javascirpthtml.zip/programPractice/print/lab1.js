// Define a simple function
function greet(message) {
    console.log(`${message}, ${this.name}!`);}
  // Create an object
  const person = {
    name: 'John'};
  // Use call to invoke the greet function with a specific 'this' value
  greet.call(person, 'Hello');
  // Output: Hello, John!

  // Define a 'user' object with a greet function
const user = {
    name: 'Alice',
    greet: function (message) {
      console.log(`${message}, ${this.name}!`);}};

  const anotherUser = {
    name: 'Bob'};
    
  user.greet.call(anotherUser, 'Hi');
  // Output: Hi, Bob!
  
  
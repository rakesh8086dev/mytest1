// sumOfEvenNumbers 
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const sumOfEvenNumbers = numbers.reduce((sum, number) => {
  if (number % 2 === 0) {
    return sum + number;
  }
  return sum;
}, 0);
console.log(sumOfEvenNumbers); // Output: 30


//what is palindrome number in javascript
function isPalindrome(number) {
  // Convert the number to a string
  const numberString = String(number);

  // Reverse the string
  const reversedString = numberString.split('').reverse().join('');

  // Compare the original string with the reversed string
  return numberString === reversedString;
}
// Example usage
console.log(isPalindrome(121));  // Output: true
console.log(isPalindrome(12321));  // Output: true
console.log(isPalindrome(1001));  // Output: true
console.log(isPalindrome(12345));  // Output: false

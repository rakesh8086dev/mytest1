// Traditional function
function traditionalFunction() {
    console.log("traditionalFunction",this); // 'this' refers to the caller
    return function() {
      console.log("traditionalFunction1",this); // 'this' refers to the caller
    };
  }
  
  // Arrow function
  const arrowFunction = () => {
    console.log("arrowFunction",this); // 'this' is inherited from the enclosing scope
    return () => {
      console.log("arrowFunction1",this); // 'this' is inherited from the enclosing scope
    };
  };
  
 
 //console.log(arrowFunction()())

console.log(traditionalFunction())
  
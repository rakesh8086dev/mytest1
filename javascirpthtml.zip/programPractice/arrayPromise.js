const asyncTask = [
    async () => {
        console.log("1 started");
        await new Promise((resolve) => setTimeout(resolve, 1000));
        console.log("1 end");
    },
    async () => {
        console.log("2 started");
        await new Promise((resolve) => setTimeout(resolve, 2000));
        console.log("2 end");
    },
    async () => {
        console.log("3 started");
        await new Promise((resolve, reject) => setTimeout(resolve, 500));
        console.log("3 end");
    },
];

async function executeSequentially(tasks) {
    for (const task of tasks) {
      try {
        await task();
      } catch (error) {
        console.error("Error occurred:", error);
      }
    }
  }
  
  executeSequentially(asyncTask);

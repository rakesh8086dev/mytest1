console.log(...[1,2,3]);
const stu = {
    sid: 101,
    sname: "Sri",
    email: 'sri@jlc',
    };
    
    console.log({...stu});
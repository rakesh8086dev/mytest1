// Promises Advantages:
// Promises allow better handling of errors using the .catch() method.
// They support chaining with the .then() method, making code more readable.
// Promises can be easily converted into async/await syntax for even cleaner code.

 function fetchData() {
    return new Promise(function(resolve, reject) {
      setTimeout(function() {
        console.log("Data fetched!");
        resolve();
      }, 1000);
    });
  }
  
  async function fetchDataAndHandle() {
    try {
      await fetchData();
      console.log("Async/Await: Data fetched!");
    } catch (error) {
      console.error("Async/Await: Error:", error);
    }
  }
  
  fetchDataAndHandle();
  
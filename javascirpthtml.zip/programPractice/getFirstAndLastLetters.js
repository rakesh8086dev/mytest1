//get first letter and last letter of name of word in javascript
function getFirstAndLastLetters(word) {
  var firstLetter = word.charAt(0);
  var lastLetter = word.charAt(word.length - 1);
  
  return [firstLetter, lastLetter];
}

// Usage example
var word = "JavaScript";
var result = getFirstAndLastLetters(word);

console.log("First letter:", result[0]);
console.log("Last letter:", result[1]);

// Reverse the any number
function reverseNumber(number) {
  var reversedString = '';
  var numberString = number.toString();
  for (var i = numberString.length - 1; i >= 0; i--) {
    reversedString += numberString.charAt(i);
  }
var reversedNumber= parseInt(reversedString);

  return reversedNumber;
}

var number = 456;
var reversed = reverseNumber(number);
console.log(reversed); // Output: 654

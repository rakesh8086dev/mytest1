function generatePascalsTriangle(rows) {
    let triangle = [];

    for (let i = 0; i < rows; i++) {
        triangle[i] = [];
        triangle[i][0] = 1;

        for (let j = 1; j < i; j++) {
            triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
        }

        triangle[i][i] = 1;
    }

    return triangle;
}

function printPascalsTriangle(triangle) {
    for (let i = 0; i < triangle.length; i++) {
        console.log(triangle[i].join(' '));
    }
}

// Change the value of 'numRows' to generate Pascal's Triangle with a different number of rows
const numRows = 5;
const pascalsTriangle = generatePascalsTriangle(numRows);
printPascalsTriangle(pascalsTriangle);

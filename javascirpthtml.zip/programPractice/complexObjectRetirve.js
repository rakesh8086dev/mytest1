const array1 = [
    { id: 1, 
    name: 'John' ,
    state:[{
          city:"patna",
          address:[{
             village:"patna"
          },{
            village:"patna1"
         }]
    }]
},
{ id: 1, 
    name: 'John' ,
    state:[{
          city:"patna",
          
    }]
} 
  ];
  
  let tempValue=[];
  array1.forEach((val)=>{
          val.state.forEach((val1)=>{
          
            val1.address?.forEach((val2)=>{
                console.log(val2);
                tempValue.push(val2)
            })
          })
  })

  console.log("tempValue",tempValue);
function canJump(nums) {
    let maxReach = 0;
    for (let i = 0; i < nums.length; i++) {
        if (i > maxReach) {
            return false; // if current index cannot be reached, return false
        }
        maxReach = Math.max(maxReach, i + nums[i]); // update the maximum reachable index
        if (maxReach >= nums.length - 1) {
            return true; // if we can reach or go beyond the last index, return true
        }
    }
    return false; // if loop finishes without reaching last index, return false
}

// Example 1
const nums1 = [2, 3, 1, 1, 4];
console.log("Example 1:");
console.log("Input: ", nums1);
console.log("Output: ", canJump(nums1));

// Example 2
const nums2 = [3, 2, 1, 0, 4];
console.log("\nExample 2:");
console.log("Input: ", nums2);
console.log("Output: ", canJump(nums2));


// Jump Game II
// Example 1:
// Input: nums = [2,3,1,1,4]
// Output: 2
// Explanation: The minimum number of jumps to reach the last index is 2. Jump 1 step from index 0 to 1, then 3 steps to the last index.

// Example 2:
// Input: nums = [2,3,0,1,4]
// Output: 2

var jump = function(nums) {
    let len = nums.length - 1 , curr = -1, next = 0, ans= 0
    for(let i =0 ; next<len; i++){
        if(i>curr) {
            ans++
            curr = next
        }
        next = Math.max(next, nums[i] + i)
    }
    return ans
};

// Example 1
const nums11 = [2,3,1,1,4];
console.log("Example 1:");
console.log("Input: ", nums11);
console.log("Output: ", jump(nums11));

// Example 2
const nums22 = [2,3,0,1,4];
console.log("\nExample 2:");
console.log("Input: ", nums22);
console.log("Output: ", jump(nums22));

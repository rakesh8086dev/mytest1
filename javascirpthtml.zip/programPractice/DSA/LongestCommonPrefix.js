function longestCommonPrefix(strs) {
    if (strs.length === 0) return "";

    let prefix = strs[0];

    strs.map(str => {
        let i = 0;
        while (i < prefix.length && i < str.length && prefix[i] === str[i]) {
            i++;
        }
        prefix = prefix.slice(0, i);
    });

    return prefix;
}

// Example usage:
const strings = ["flower", "flow", "flight"];
console.log(longestCommonPrefix(strings)); // Output: "fl"
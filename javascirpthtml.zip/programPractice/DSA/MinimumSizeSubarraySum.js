var minSubArrayLen = function(target, nums) {
    let start = 0;
    let end = 0;
    let currentSum = 0;
    let shortestLength = Number.MAX_VALUE;
    while (start < nums.length && end < nums.length) {
        currentSum += nums[end];
        while (currentSum >= target) {
            shortestLength = Math.min(shortestLength, end - start + 1);
            currentSum -= nums[start];
            start++;
        }
        end++;
    }
    return shortestLength === Number.MAX_VALUE ? 0 : shortestLength;
};

// other solution 

// var minSubArrayLen = function(target, nums) {
//     let i=0, sum=0, len = Infinity;
//     for(let j in nums){
//         sum += nums[j];
//         while(sum >= target){
//             len = Math.min((j-i)+1, len)
//             sum -= nums[i]
//             i++;
//         }
//     }
//     return len !== Infinity? len : 0;
// };

// Example 1:

// Input: target = 7, nums = [2,3,1,2,4,3]
// Output: 2
// Explanation: The subarray [4,3] has the minimal length under the problem constraint.

// Example 2:
// Input: target = 4, nums = [1,4,4]
// Output: 1

// Example 3:
// Input: target = 11, nums = [1,1,1,1,1,1,1,1]
// Output: 0
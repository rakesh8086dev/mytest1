var majorityElement = function(nums) {
    let count = 0, leader;
    for (let i=0; i<nums.length; i++) {
        if (count < 1) leader = nums[i]
        if (nums[i] == leader) count++;
        else count--;
    }
    return leader;
};

console.log(majorityElement([3, 2, 3])); // Output: 3
console.log(majorityElement([2, 2, 1, 1, 1, 2, 2])); // Output: 2
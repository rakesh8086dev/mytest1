//What is type coercion in JavaScript?
//Type coercion is the automatic conversion of values from one data type to another.

//What happens when you add a number to a string in JavaScript?
//When you add a number to a string, JavaScript coerces the number into a string and concatenates it with the other string.
console.log("5" + 3); // Output: "53"

//How does JavaScript handle subtraction of a number from a string?
//JavaScript tries to convert the string to a number before performing subtraction.
console.log("5" - 3); // Output: 2

//Explain the result of multiplying a string with a number in JavaScript.
//JavaScript coerces the string into a number before performing multiplication.
console.log("5" * 3); // Output: 15

//What is the outcome of dividing a string by a number in JavaScript?
//JavaScript coerces the string into a number before performing division.
console.log("5" / 3); // Output: 1.66667

//How does JavaScript handle concatenation when using the + operator?
//JavaScript converts non-string values to strings before concatenation.
console.log("Hello" + 42); // Output: "Hello42"

//What happens if you use the - operator with a string that cannot be converted to a number?
//JavaScript converts the string into NaN (Not-a-Number).
console.log("Hello" - 10); // Output: NaN

//Explain the result of multiplying a string containing non-numeric characters with a number.
//JavaScript coerces the string into NaN before performing multiplication.
console.log("Hello" * 5); // Output: NaN

//What does JavaScript return when dividing a non-numeric string by a number?
//JavaScript coerces the string into NaN before performing division.
console.log("Hello" / 2); // Output: NaN

//How does JavaScript handle arithmetic operations with strings containing leading numeric characters?
//JavaScript performs arithmetic operations on strings starting from the left until it encounters a non-numeric character.
console.log("10" - "2" + "5"); // Output: "85"

//What is the output of adding an empty string to a number?
//JavaScript coerces the number into a string and concatenates it with the empty string.
console.log(42 + ""); // Output: "42"

//Explain the result of subtracting an empty string from a number.
//JavaScript coerces the empty string into 0 before performing subtraction.
console.log(42 - ""); // Output: 42

//How does JavaScript handle multiplication with an empty string?
//JavaScript coerces the empty string into 0 before performing multiplication.
console.log(42 * ""); // Output: 0

//What is the outcome of dividing a number by an empty string in JavaScript?
//JavaScript coerces the empty string into 0 before performing division.
console.log(42 / ""); // Output: Infinity

//Explain the output of adding a string containing only whitespace to a number.
//JavaScript coerces the number into a string and concatenates it with the whitespace string.
console.log(42 + "   "); // Output: "42   "

//What is the result of subtracting a string containing only whitespace from a number?
//JavaScript coerces the whitespace string into 0 before performing subtraction.
console.log(42 - "   "); // Output: 42

//How does JavaScript handle multiplication with a string containing only whitespace?
//JavaScript coerces the whitespace string into 0 before performing multiplication.
console.log(42 * "   "); // Output: 0

//What happens if you divide a number by a string containing only whitespace in JavaScript?
//JavaScript coerces the whitespace string into 0 before performing division.
console.log(42 / "   "); // Output: Infinity

//Explain the output of adding a string containing a mix of numbers and letters to a number.
//JavaScript coerces the number into a string and concatenates it with the mixed string.
console.log(42 + "abc"); // Output: "42abc"

//What is the result of subtracting a string containing a mix of numbers and letters from a number?
//JavaScript coerces the mixed string into NaN before performing subtraction.
console.log(42 - "abc"); // Output: NaN

console.log("5" + 3); // Output: "53"

console.log("5" - 3); // Output: 2

console.log("5" * 3); // Output: 15

console.log("5" / 3); // Output: 1.66667

console.log("02" - 1); // Output: 1

console.log(5 + ""); // Output: "5"

console.log("42" * ""); // Output: 0

console.log("Hello" - 3); // Output: NaN (Not a Number)

console.log("Hello" / 5); // Output: NaN (Not a Number)

console.log(true + "5"); // Output: "true5"

console.log(1/0); // Output: "Infinity"
function findMaxMatchingOccurrence(words) {
    if (words.length === 0) return '';

    let prefix = '';
    let maxPrefix = '';

    // Iterate through the characters of the first word
    for (let i = 0; i < words[0].length; i++) {
        // Assume the current character as the potential prefix
        prefix += words[0][i];

        // Check if the prefix exists in all words
        for (let j = 1; j < words.length; j++) {
            if (!words[j].startsWith(prefix)) {
                // If not, return the current maxPrefix
                return maxPrefix;
            }
        }

        // Update maxPrefix if the current prefix is longer
        if (prefix.length > maxPrefix.length) {
            maxPrefix = prefix;
        }
    }

    return maxPrefix;
}

const words = ["flower", "flow", "flight"];
const maxMatching = findMaxMatchingOccurrence(words);
console.log("maxMatching",maxMatching);
//What is the difference between == and === in JavaScript?
Example:
console.log(5 == "5"); // true
console.log(5 === "5"); // false

//What does type coercion mean in JavaScript? How does it affect == comparisons?
Example:
console.log(1 == true); // true
console.log(0 == false); // true

//How does JavaScript handle comparisons between different data types with ==?
Example:
console.log(null == undefined); // true

//Explain the concept of truthy and falsy values in JavaScript in the context of == comparison.
Example:
console.log(0 == false); // true
console.log('' == false); // true

//What is the result of comparing objects with == in JavaScript?
Example:
const obj1 = {};
const obj2 = {};
console.log(obj1 == obj2); // false

//How does JavaScript compare arrays with ==?
Example:
console.log([1, 2] == "1,2"); // true

//Explain how JavaScript compares strings and numbers with ==.
Example:
console.log("2" == 2); // true

//What happens when you compare a string with an object using ==?
Example:
console.log({} == "[object Object]"); // true

//Describe the result of comparing null and undefined with ==.
Example:
console.log(null == undefined); // true

//How does JavaScript handle comparisons between different object types with ==?
Example:
console.log({} == "[object Object]"); // true

//Explain the result of comparing a number with a boolean using ==.
Example:
console.log(1 == true); // true

//What happens when you compare a boolean with a string using ==?
Example:
console.log(true == "true"); // false

//Describe the outcome of comparing an empty array with a boolean using ==.
Example:


console.log([] == false); // true
//How does JavaScript compare arrays with different elements using ==?
Example:
console.log([1, 2] == [1, 2]); // false

//Explain what happens when you compare NaN with anything using ==.
Example:
console.log(NaN == NaN); // false

//Describe the result of comparing 0 with an empty string using ==.
Example:
console.log(0 == ""); // true

//How does JavaScript compare two empty objects using ==?
Example:
console.log({} == {}); // false

//Explain the result of comparing a string with an array using ==.
Example:
console.log("hello" == ["h", "e", "l", "l", "o"].join("")); // true

//Describe the outcome of comparing an empty string with false using ==.
Example:
console.log("" == false); // true

//How does JavaScript compare undefined and null with other values using ==?
Example:
console.log(null == 0); // false
console.log(undefined == 0); // false
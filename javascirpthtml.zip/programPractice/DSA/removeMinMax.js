function removeMinMax(arr) {
    // Find minimum and maximum values in the array
    let min = Math.min(...arr);
    let max = Math.max(...arr);

    // Find indexes of minimum and maximum elements
    let minIndex = arr.indexOf(min);
    let maxIndex = arr.indexOf(max);

    // Remove the minimum and maximum elements from the array
    arr.splice(minIndex, 1);
    arr.splice(maxIndex > minIndex ? maxIndex - 1 : maxIndex, 1); // Adjust index if needed

    return arr;
}

// Example usage:
let numbers = [5, 3, 8, 2, 1, 9, 4, 7, 6];
let modifiedArray = removeMinMax(numbers);
console.log(modifiedArray); // Output: [3, 5, 8, 2, 4, 7, 6]

// Input: l1 = [2,4,3], l2 = [5,6,4]
// Output: [7,0,8]
// Explanation: 342 + 465 = 807.
// Example 2:

// Input: l1 = [0], l2 = [0]
// Output: [0]
// Example 3:

// Input: l1 = [9,9,9,9,9,9,9], l2 = [9,9,9,9]
// Output: [8,9,9,9,0,0,0,1]

function reverseAndSumArrays(l1, l2) {
    // Reverse both arrays without using reverse()
    for (let i = 0, j = l1.length - 1; i < j; i++, j--) {
        let temp = l1[i];
        l1[i] = l1[j];
        l1[j] = temp;
    }
    
    for (let i = 0, j = l2.length - 1; i < j; i++, j--) {
        let temp = l2[i];
        l2[i] = l2[j];
        l2[j] = temp;
    }
    
    // Initialize an empty array to store the result
    let result = [];
    let carry = 0;
    let maxLength = Math.max(l1.length, l2.length);
    
    // Iterate over the arrays
    for (let i = 0; i < maxLength; i++) {
        // Get the current digits from the arrays, if they exist
        let digit1 = i < l1.length ? l1[i] : 0;
        let digit2 = i < l2.length ? l2[i] : 0;
        
        // Sum the digits along with any carry from the previous addition
        let sum = digit1 + digit2 + carry;
        
        // Update the carry for the next iteration
        carry = Math.floor(sum / 10);
        
        // Store the result after removing the carry
        result.unshift(sum % 10);
    }
    
    // If there's any carry left after iterating over all digits, add it to the result
    if (carry > 0) {
        result.unshift(carry);
    }
    
    return result;
}

// Test the function

// let l1 = [2, 4, 3];
// let l2 = [5, 6, 4];
let l1 = [9,9,9,9,9,9,9];
let l2 = [9,9,9,9];
console.log(reverseAndSumArrays(l1, l2)); // Output: [7, 0, 8]

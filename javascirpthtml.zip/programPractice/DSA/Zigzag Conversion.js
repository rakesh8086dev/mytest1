function convert(s, numRows) {
    if (numRows === 1) return s;

    const rows = new Array(numRows).fill('');
    let rowIndex = 0;
    let direction = 1;

    for (let i = 0; i < s.length; i++) {
        rows[rowIndex] += s[i];
        if (rowIndex === 0) {
            direction = 1;
        } else if (rowIndex === numRows - 1) {
            direction = -1;
        }
        rowIndex += direction;
    }

    return rows.join('');
}

// Example usage:
const inputString = "PAYPALISHIRING";
const numRows = 3;
console.log(convert(inputString, numRows)); // Output: "PAHNAPLSIIGYIR"

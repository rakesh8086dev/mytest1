function mergeSortedLists(list1, list2) {
    let mergedList = [];
    let i = 0;
    let j = 0;

    // Merge the two lists while both of them have elements
    while (i < list1.length && j < list2.length) {
        if (list1[i] < list2[j]) {
            mergedList.push(list1[i]);
            i++;
        } else {
            mergedList.push(list2[j]);
            j++;
        }
    }

    // Add the remaining elements of list1 (if any)
    while (i < list1.length) {
        mergedList.push(list1[i]);
        i++;
    }

    // Add the remaining elements of list2 (if any)
    while (j < list2.length) {
        mergedList.push(list2[j]);
        j++;
    }

    return mergedList;
}

// Test case
const list1 = [1, 2, 4];
const list2 = [1, 3, 4];
const merged = mergeSortedLists(list1, list2);
console.log(merged); // Output: [1, 1, 2, 3, 4, 4]

function countVowelsLetterWise(str) {
    // Convert the string to lowercase to handle both uppercase and lowercase vowels
    str = str.toLowerCase();
    
    // Initialize an object to store the count of vowels for each letter
    let vowelCount = {};
    
    // Define an array of vowels
    const vowels = ['a', 'e', 'i', 'o', 'u'];
    
    // Iterate through each character of the string
    for (let i = 0; i < str.length; i++) {
        // Get the current character
        let char = str[i];
        
        // Check if the current character is a vowel
        if (vowels.includes(char)) {
            // If the current character is a vowel, update the count in the vowelCount object
            if (!vowelCount[char]) {
                vowelCount[char] = 1;
            } else {
                vowelCount[char]++;
            }
        }
    }
    
    return vowelCount;
}

// Example usage:
const str = "Hello World";
const result = countVowelsLetterWise(str);
console.log(result);

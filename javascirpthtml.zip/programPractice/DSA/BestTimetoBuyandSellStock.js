// Best Time to Buy and Sell Stock

// Example 1:

// Input: prices = [7,1,5,3,6,4]
// Output: 5
// Explanation: Buy on day 2 (price = 1) and sell on day 5 (price = 6), profit = 6-1 = 5.
// Note that buying on day 2 and selling on day 1 is not allowed because you must buy before you sell.

// Example 2:
// Input: prices = [7,6,4,3,1]
// Output: 0
// Explanation:

var maxProfit = function(prices) {
    let min=prices[0],profit=0;
   for(let i = 1; i < prices.length; i++){
       min = Math.min(min,prices[i]);
       profit = Math.max(profit,prices[i]-min)
   }
   return profit;
};

// Example 1
const prices1 = [7, 1, 5, 3, 6, 4];
console.log("Example 1:");
console.log("Input: ", prices1);
console.log("Output: ", maxProfit(prices1));

// Example 2
const prices2 = [7, 6, 4, 3, 1];
console.log("\nExample 2:");
console.log("Input: ", prices2);
console.log("Output: ", maxProfit(prices2));

// Best Time to Buy and Sell Stock II

function maxProfit1(prices) {
    let totalProfit = 0;
    
    for (let i = 1; i < prices.length; i++) {
        if (prices[i] > prices[i - 1]) {
            totalProfit += prices[i] - prices[i - 1];
        }
    }
    
    return totalProfit;
}

// Example 1
const prices11 = [7, 1, 5, 3, 6, 4];
console.log("Example 1:");
console.log("Input: ", prices11);
console.log("Output: ", maxProfit1(prices11));

// Example 2
const prices22 = [1, 2, 3, 4, 5];
console.log("\nExample 2:");
console.log("Input: ", prices22);
console.log("Output: ", maxProfit1(prices22));

// Example 3
const prices3 = [7, 6, 4, 3, 1];
console.log("\nExample 3:");
console.log("Input: ", prices3);
console.log("Output: ", maxProfit1(prices3));

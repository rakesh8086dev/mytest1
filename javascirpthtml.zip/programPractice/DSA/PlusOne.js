var plusOne = function(digits) {
    let addNext = true
     for (let i = digits.length - 1; i >= 0 && addNext; i--) {
       digits[i] += 1
       if (digits[i] > 9) {
         digits[i] = 0
         addNext = true
       } else {
         addNext = false
       }
     } 
  
     if (addNext) {
       digits.unshift(1)
     }
  
     return digits
  };
  let input1 = [1,2,3];
  console.log("input1:", input1);
  let output1 = plusOne(input1);
  console.log("output1",output1);
  console.log("---------------");
  
  let input2 = [4,3,2,1];
  console.log("input2:", input2);
  let output2 = plusOne(input2);
  console.log("output2",output2);
  console.log("---------------");
  
  let input3 = [1,0,9];
  console.log("input3:", input3);
  let output3 = plusOne(input3);
  console.log("output3",output3);
  console.log("---------------");



//   Example 1:

// Input: digits = [1,2,3]
// Output: [1,2,4]
// Explanation: The array represents the integer 123.
// Incrementing by one gives 123 + 1 = 124.
// Thus, the result should be [1,2,4].
// Example 2:

// Input: digits = [4,3,2,1]
// Output: [4,3,2,2]
// Explanation: The array represents the integer 4321.
// Incrementing by one gives 4321 + 1 = 4322.
// Thus, the result should be [4,3,2,2].
// Example 3:

// Input: digits = [9]
// Output: [1,0]
// Explanation: The array represents the integer 9.
// Incrementing by one gives 9 + 1 = 10.
// Thus, the result should be [1,0].
 
var isPalindrome = function(s) {
    const cleaned  = s.trim().toLowerCase().replace(/[^a-z0-9]/g,'');

            for(let i =0 ;i< cleaned.length-1;i++){
                  if(cleaned[i] != cleaned[cleaned.length-1-i]){
                        return false;
                  }
            }
            return true;
};

let input1 = "A man, a plan, a canal: Panama";
console.log("input1:", input1);
let output1 = isPalindrome(input1);
console.log("output1",output1);
console.log("---------------");

let input2 =  "race a car";
console.log("input2:", input2);
let output2 = isPalindrome(input2);
console.log("output2",output2);
console.log("---------------");

let input3 = " ";
console.log("input3:", input3);
let output3 = isPalindrome(input3);
console.log("output3",output3);
console.log("---------------");



// Example 1:

// Input: s = "A man, a plan, a canal: Panama"
// Output: true
// Explanation: "amanaplanacanalpanama" is a palindrome.
// Example 2:

// Input: s = "race a car"
// Output: false
// Explanation: "raceacar" is not a palindrome.
// Example 3:

// Input: s = " "
// Output: true
// Explanation: s is an empty string "" after removing non-alphanumeric characters.
// Since an empty string reads the same forward and backward, it is a palindrome.
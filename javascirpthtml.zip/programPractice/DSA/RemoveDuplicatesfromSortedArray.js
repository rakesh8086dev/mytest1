function removeDuplicates(nums) {
    if (nums.length === 0) return 0;
 
    let i = 0;
    for (let j = 1; j < nums.length; j++) {
      if (nums[i] !== nums[j]) {
        i++;
        nums[i] = nums[j];
      }
    }
    return i + 1;
}

// Test cases
let nums1 = [1, 1, 2];
console.log("Example 1:");
console.log("Input:", nums1);
console.log("Output:", removeDuplicates(nums1), ", nums =", nums1);

let nums2 = [0, 0, 1, 1, 1, 2, 2, 3, 3, 4];
console.log("\nExample 2:");
console.log("Input:", nums2);
console.log("Output:", removeDuplicates(nums2), ", nums =", nums2);


//Remove Duplicates from Sorted Array II
function removeDuplicates11(nums) {
  let set = new Set();
  let j =0;
  for(let i=0;i<nums.length;i++){
      if(nums[i]!=nums[i+1] || nums[i]!=nums[i+2] ) {
          nums[j] = nums[i];
          j++;
      }
  }
  return j;
};
// other solution
var removeDuplicates = function(nums) {
  let c=0 ;
 
 for(let i=0 ; i<nums.length ; i++){
     if(nums[i] !== nums[i+2]){
         nums[c] = nums[i];
         c++
     }
 }

 return c;
};

let nums3 = [1, 1, 1, 2, 2, 3];
console.log(removeDuplicates11(nums3)); // Output: 5
console.log(nums3); // Output: [1, 2, 3, '_', '_', '_']

let nums4 = [0, 0, 1, 1, 1, 1, 2, 3, 3];
console.log(removeDuplicates11(nums4)); // Output: 7
console.log(nums4); // Output: [0, 1, 2, 3, '_', '_', '_', '_', '_']
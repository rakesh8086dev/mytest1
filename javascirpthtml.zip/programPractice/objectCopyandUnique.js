//Merge Two array and store unique value
const array1 = [
  { id: 1, name: 'John' },
  { id: 2, name: 'Alice' },
  { id: 3, name: 'Bob' }
];

const array2 = [
  { id: 3, name: 'Bob' },
  { id: 4, name: 'Eve' },
  { id: 5, name: 'Tom' }
];

const mergeUniqueObjects = (arr1, arr2) => {
  const merged = [...arr1, ...arr2];

  const unique = merged.reduce((result, obj) => {
    const existingObj = result.find(item => item.id === obj.id);
    if (!existingObj) {
      result.push(obj);
    }
    return result;
  }, []);

  return unique;
};

const mergedArray = mergeUniqueObjects(array1, array2);
console.log(mergedArray);



// input: aaabbbccdd write a program in javascirpt output: a3b3c2d2
   let  str="aaabbbccdd" 
   const characterCount = {};
   for (let i = 0; i < str.length; i++) {
     const char = str[i];
     if (characterCount[char]) {
       characterCount[char]++;
     } else {
       characterCount[char] = 1;
     }
   }
    var resultConcatenation = ""
   for (var key in characterCount) {
    resultConcatenation += key+characterCount[key];
  }
   console.log(characterCount); //{ a: 3, b: 3, c: 2, d: 2 }
   console.log(resultConcatenation); //a3b3c2d2
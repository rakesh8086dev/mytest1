(async function(){
    await setTimeout(() => console.log('Aakash'), 3000);
    console.log('Hi');
})();

(async function(){
    await customSetTimeout(() => console.log('Aakash'), 3000);
    console.log('Hi');
})();

function customSetTimeout(cb, ms) {
    return new Promise((resolve)=>{
        setTimeout(()=>{
            resolve(cb());
        },ms)
    })
}
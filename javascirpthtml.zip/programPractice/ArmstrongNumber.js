//Check ArmstrongNumber
const isArmstrongNumber = (number) => {
  const digits = number.toString().split('');
  console.log("digits",digits);
  const exponent = digits.length;
   const sum = digits.reduce((acc, digit) => {
    return acc + Math.pow(parseInt(digit), exponent);
  }, 0);
   return sum === number;
};
// Example usage:
console.log(isArmstrongNumber(153)); // true



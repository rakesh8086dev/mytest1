//How do you sort elements in an array
function bubbleSort(arr) {
  var len = arr.length; //5
  for (var i = 0; i < len - 1; i++) { // 4
    for (var j = 0; j < len - 1 - i; j++) { //3
      if (arr[j] > arr[j + 1]) {
        // Swap elements
        var temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
      }
    }
  }
  return arr;
}
// Example usage
var myArray = [5, 3, 8, 2, 1, 4];
console.log(bubbleSort(myArray)); // Output: [1, 2, 3, 4, 5, 8]


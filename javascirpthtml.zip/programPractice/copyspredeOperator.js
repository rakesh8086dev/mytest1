let arr=[1,2,3]
let arr1=[1,2,3,...arr]
//console.log(arr1);

let obj={"name":"rakesh"}
let obj1={"name":"Mahesh",...obj}
console.log(obj1)
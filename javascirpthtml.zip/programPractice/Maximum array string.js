//Maximum length in array string
const strings = ['apple', 'banana', 'cherry', 'dragonfruit'];
const maxLength = strings.reduce((max, str) => {
  return Math.max(max, str.length);
}, 0);
console.log(maxLength); // Output: 11 (the length of 'dragonfruit')

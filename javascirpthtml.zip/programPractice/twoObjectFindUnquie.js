// Find a common value from two array object
const array1 = [
  { id: 1, name: 'John' },
  { id: 2, name: 'Jane' },
  { id: 3, name: 'Alice' }
];const array2 = [
  { id: 3, name: 'Alice' },
  { id: 4, name: 'Bob' },
  { id: 5, name: 'Charlie' }
];
const commonValues = array1.filter(obj1 => array2.some(obj2 => obj2.id === obj1.id));
console.log(commonValues);

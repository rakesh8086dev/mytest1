// Remove duplicate value

const array1 = [1, 2, 3, 4, 4, 5, 6, 6];
const uniqueArray1 = array1.filter((value, index, self) => self.indexOf(value) === index);
console.log(uniqueArray1);

// second program
const array = [1, 2, 3, 4, 4, 5, 6, 6];
const uniqueArray = array.reduce((accumulator, value) => {
  if (!accumulator.includes(value)) {
    accumulator.push(value); }
  return accumulator;
}, []);
console.log(uniqueArray);

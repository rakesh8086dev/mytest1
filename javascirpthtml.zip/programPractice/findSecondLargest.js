//findSecondLargest
const findSecondLargest = (arr) => {
  const uniqueSortedArr = [...new Set(arr)].sort((a, b) => b - a);
  if (uniqueSortedArr.length >= 2) {
    return uniqueSortedArr[1]; // Return the second element
  } else {
    return null; 
  }
};

const numbers = [10, 5, 8, 2, 9, 3];
const secondLargest = findSecondLargest(numbers);
console.log("Second largest number:", secondLargest);

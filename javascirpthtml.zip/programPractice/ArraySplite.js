function splitList(list, splitValue) {
    // Initialize an empty array to store the split subarrays
    var result = [];

    // Loop through the list and split it into subarrays
    for (var i = 0; i < list.length; i += splitValue) {
        result.push(list.slice(i, i + splitValue));
    }

    return result;
}

// Sample input
var list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
var splitValue = 5;

// Call the function and print the result
console.log(splitList(list1, splitValue));

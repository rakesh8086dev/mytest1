
console.log("Start of the program");

setTimeout(() => {
  console.log("setTimeout");
}, 2000);

setImmediate(() => {
  console.log("setImmediate");
});

process.nextTick(() => {
  console.log("nextTick");
});

console.log("End of the program");

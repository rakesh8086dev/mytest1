function decodeString(s) {
    let stack = [];
    
    for (let i = 0; i < s.length; i++) {
        if (s[i] !== ']') {
            stack.push(s[i]);
        } else {
            let substring = '';
            let repeatString = '';
            
            while (stack[stack.length - 1] !== '[') {
                substring = stack.pop() + substring;
            }
            stack.pop(); // pop '['
            
            while (!isNaN(stack[stack.length - 1])) {
                repeatString = stack.pop() + repeatString;
            }
            repeatString = parseInt(repeatString);
            
            stack.push(substring.repeat(repeatString));
        }
    }
    
    return stack.join('');
}

console.log(decodeString("3[a]2[bc]")); // Output: aaabcbc
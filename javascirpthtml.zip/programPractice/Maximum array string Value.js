const strings = ['apple', 'banana', 'cherry', 'dragonfruit'];

let maxLength = 0;
let maxValue = '';

for (let i = 0; i < strings.length; i++) {
    const currentLength = strings[i].length;
    if (currentLength > maxLength) {
        maxLength = currentLength;
        maxValue = strings[i];
    }
}

console.log('Maximum length:', maxLength);
console.log('Corresponding string value:', maxValue);

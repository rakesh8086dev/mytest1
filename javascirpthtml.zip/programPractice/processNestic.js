console.log('Start');

// Queue a nextTick callback
process.nextTick(() => {
console.log('Next Tick 1');
});

// Schedule a timeout callback
setTimeout(() => {
console.log('Timeout 1');
}, 0);

const myPromise = Promise.resolve(1);
myPromise.then((value) => {
    console.log("Resolved value:", value); // Output: Resolved value: 1
  }).catch((error) => {
    console.error("Error occurred:", error);
  });
// Queue another nextTick callback
process.nextTick(() => {
console.log('Next Tick 2');
});

// // setImmediate call
setImmediate(function() {
console.log("Inside setImmediate callback");
});

// // Trigger an IO callback
// require('fs').stat(__filename, () => {
// console.log('File IO 1');
// });

console.log('End');
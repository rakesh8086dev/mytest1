//occurance "r" in a string in javascript

const str1 = "Hello, world! This is a sample string.";
const regex = /r/g; // 'r' is the letter you want to count

const occurrences1 = (str1.match(regex) || []).length;
console.log(occurrences1); // Output: 4

/// another program
const str = "Hello, world! This is a sample string.";
const letterToCount = "r";
let occurrences = 0;

for (let i = 0; i < str.length; i++) {
  if (str[i] === letterToCount) {
    occurrences++;
  }
}

console.log(occurrences); // Output: 4


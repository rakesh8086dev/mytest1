function findFirstOddMissingNumber(arr) {
    let max = Math.max(...arr);
    console.log("max",max);
    for (let i = 1; i <= max; i += 2) {
        if (!arr.includes(i)) {
            return i;
        }
    }

    return max + 2; // If all odd numbers are present, return the next odd number
}

let temp = [5, 7, 9, 15];
let result = findFirstOddMissingNumber(temp);

console.log("The first odd missing number is:", result);


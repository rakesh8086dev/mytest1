// Reverse the each word in sentance
function reverseWords(sentence) {
  
 var words = sentence.split(' ');
 var reversedWords = words.map(function(word) {
    return word.split('').reverse().join('');
  });
var reversedSentence = reversedWords.join(' ');
return reversedSentence;
}

var sentence = "Hello, world!";
var reversedSentence = reverseWords(sentence);
console.log(reversedSentence); // Output: olleH, dlrow!

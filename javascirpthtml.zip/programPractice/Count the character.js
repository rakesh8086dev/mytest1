// Count the character number of times
const str = "hello world";
const characterCount = {};
for (let i = 0; i < str.length; i++) {
  const char = str[i];
  if (characterCount[char]) {
    characterCount[char]++;
  } else {
    characterCount[char] = 1;
  }
}
console.log(characterCount);

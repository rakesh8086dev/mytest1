//Find the two letter in sentance
const str = "Hello world example";
// First letter of the string
const firstLetter = str.charAt(0);
console.log("First letter:", firstLetter);
// First letter of the last word
const words = str.split(" ");
const lastWord = words[words.length - 1];
const lastWordFirstLetter = lastWord.charAt(0);
console.log("First letter of the last word:", lastWordFirstLetter);

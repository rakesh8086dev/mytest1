let str = ['ram', 'manish', 'naresh'];
let inputString = 'mnr';
let outarr=[];
function customSort(arr, inputString) {
    for (let char of inputString) {
        let findStr = str.find(function (element) {
            return element.startsWith(char);
          });
        outarr.push(findStr);
    }
  
}
customSort(str,inputString);
console.log("outarr",outarr);
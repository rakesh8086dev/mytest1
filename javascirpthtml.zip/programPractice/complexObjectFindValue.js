const nestedObjects = [
    {
        name: 'First Parent',
        value: 100,
        children: [
            {
                name: 'First Child',
                value: 100,
                children: [
                    {
                        name: 'First Child',
                        value: 110,
                    },
                    {
                        name: 'Second Child',
                        value: 120,
                        children: [
                            {
                                name: 'First GrandChild',
                                value: 121,
                            },
                            {
                                name: 'Second GrandChild',
                                value: 122,
                            },
                        ]
                    },
                ]
            }
        ]
    },
    {
        name: 'Second Parent',
        value: 200,
        children: [
            {
                name: 'First Child',
                value: 210,
            },
            {
                name: 'Second Child',
                value: 220,
            },
            {
                name: 'Third Child',
                value: 230,
                children: [
                    {
                        name: 'First GrandChild',
                        value: 231,
                        children: [
                            {
                                name: 'First GrandChild',
                                value: 121,
                            },
                            {
                                name: 'Second GrandChild',
                                value: 122,
                            },
                        ]
                    }
                ]
            },
        ]
    },
];

// Function to retrieve grandchildren values
function getGrandchildrenValues(nestedObjects) {
    const grandchildrenValues = [];
    
    nestedObjects.forEach(parent => {
        if (parent.children) {
            parent.children.forEach(child => {
                if (child.children) {
                    child.children.forEach(grandchild => {
                        if (grandchild.children) {
                            grandchild.children.forEach(grandchildVal => {
                            grandchildrenValues.push(grandchildVal);});
                        }
                    });
                }
            });
        }
    });
    
    return grandchildrenValues;
}

const grandchildrenValues = getGrandchildrenValues(nestedObjects);
console.log("Grandchildren Values:", grandchildrenValues);

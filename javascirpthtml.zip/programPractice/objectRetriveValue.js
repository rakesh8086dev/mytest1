const array2 = [
    { id: 1, name: 'John',salary:14 },
    { id: 2, name: 'Jane',salary:30 },
    { id: 3, name: 'Alice',salary:40 }]
    const namesWithSalaryGreaterThan15 = array2.filter(item => item.salary > 15).map(item => item.name);
    console.log(namesWithSalaryGreaterThan15);

    const array1 = [
        { id: 1, name: 'John', salary: 14 },
        { id: 1, name: 'Jane', salary: 30 },
        { id: 3, name: 'Alice', salary: 40 }
    ];
    
    const result = array1.reduce((acc, current) => {
        const existingIndex = acc.findIndex(item => item.id === current.id);
        if (existingIndex !== -1) {
            acc[existingIndex].salary += current.salary;
        } else {
            acc.push({ id: current.id, name: current.name, salary: current.salary });
        }
        return acc;
    }, []);
    
    console.log(result);
    
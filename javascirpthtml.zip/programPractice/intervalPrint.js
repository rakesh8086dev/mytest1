// print 1 to 3 and repeat again
let counter = 0;
let intervalId;

function printEverySecond() {
  intervalId = setInterval(() => {
    console.log(counter);
    counter++;

    if (counter > 3) {
      clearInterval(intervalId);
      resetCounter();
    }
  }, 1000);
}

function resetCounter() {
  setTimeout(() => {
    counter = 0;
    printEverySecond();
  }, 4000);
}

printEverySecond();
// print 1 to 3 and repeat again


 

// An asynchronous function that returns a Promise
function getData() {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve("Data fetched successfully!");
      }, 2000); // Simulating delay
    });
  }
  
  // Asynchronous function using 'await'
  async function fetchData() {
    console.log("Fetching data...");
    
    // 'await' pauses the execution until the promise is resolved
    const result = await getData();
    
    console.log(result); // Output: Data fetched successfully!
    
    console.log("Data fetched and processed!");
  }
  
  // Call the async function
  fetchData();
  
function x(){
    var a = 7;
     function y(){
    return a+5;
     }
     return y;
    }
    var z = x();
    
   console.log("z()",z()) ;
function add(value) {
    return new Promise((resolve, reject) => {
    resolve(value + 5);
    });
    }
    
    function sub(value) {
    return new Promise((resolve, reject) => {
    resolve(value - 5);
    });
    }
    
    function mul(value) {
    return new Promise((resolve, reject) => {
    resolve(value * 5);
    });
    }
    
    
    add(5)
    .then(addRes => sub(addRes))
    .then(subRes => mul(subRes))
    .then(mulRes => {
    console.log("Result: " + mulRes);
    })
    .catch(err => {
    console.error("Error: " + err);
    });
// Javascript
/* Get the second most frequently occurring element, including the frequency count; if two numbers share the same frequency, the smallest one will be selected.*/

const sortedArray = [1, 2, 4, 4, 6, 6, 4, 6, 6, 7, 7, 9, 7, 10];
function mostRepeatedAndFreq(arr) {
	// Start code here
    let frequency = {};
    let maxFreq = 0;
    let mostRepeated;

    for (let i = 0; i < arr.length; i++) {
        const element = arr[i];
        frequency[element] = (frequency[element] || 0) + 1;
        if (frequency[element] > maxFreq) {
            maxFreq = frequency[element];
            mostRepeated = element;
        }
    }

    return { mostRepeated, frequency: maxFreq };
}

const result = mostRepeatedAndFreq(sortedArray);
console.log(result); // [4, 3] // Where 4 is the second most repeated element and 3 is the Frequency count

// Example 1: Using a function as an argument
function higherOrderFunction(callback) {
    console.log("Executing the higher-order function");
    callback(); // Invoking the callback function
  }
  
  function callbackFunction() {
    console.log("I am a callback function");
  }
  
  higherOrderFunction(callbackFunction);
  
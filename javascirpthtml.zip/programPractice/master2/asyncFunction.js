// Normal function
function normalFunction() {
    console.log("syn Normal function started");
   setTimeout(()=>{
console.log("hello syncronus")
   },2000)
    console.log("syn Normal function ended");
}

// Async function
async function asyncFunction() {
    console.log("Async function started");
    setTimeout(()=>{
        console.log("hello Asyncronus")
           },2000)
    console.log("Async function ended");
}
normalFunction(); // This blocks until normalFunction is finished
asyncFunction(); // This does not block, other code can execute while waiting for asyncFunction to complete


// async allows other code to run while it's waiting for an asynchronous operation to complete. Asynchronous operations are tasks that may take some time to finish.

//A normal function in programming executes synchronously, meaning it runs from start to finish, and while it's executing, it blocks other code from running. Once it's finished executing, it returns a result.


function mainFunction(arg1, arg2, callback) {
    // Perform some operations
    let result = arg1 + arg2;

    // Invoke the callback function
    callback(result);
    console.log("Hello world")
}

function callbackFunction(value) {
    setTimeout(()=>{
        console.log("Hello setTimeout")  
    },3000)
    console.log("The result is: " + value);
}

// Usage: Pass callbackFunction as an argument
mainFunction(10, 20, callbackFunction);
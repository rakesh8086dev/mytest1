//const promise1 = new Promise(1);
//const promise2 = new Promise(2);
const promise3 = Promise.resolve(3);
console.log("promise3",promise3)
 setTimeout(()=>{
 console.log("test");
 },0)
//console.log("promise1",promise1)
//console.log("promise2",promise2)


const firstPromise = new Promise((resolve) => {

    setTimeout(() => {
  
      resolve("First promise resolved");
  
    }, 1000); });

    
  
  const secondPromise = (data) => {
  
    return new Promise((resolve) => {
  
      setTimeout(() => {
  
        resolve(`${data} - Second promise resolved`);
  
      }, 1000);
  
    });  };

  //   console.log("firstPromise",firstPromise);
  //  async function getdata(){
  //        const getval= await firstPromise;
  //        console.log("getval",getval);
  //  }
  //             getdata();



  firstPromise.then((result) => {
  
      return secondPromise(result);
  
   }).then((finalResult) => {
  
      console.log(finalResult); // Output: First promise resolved - Second promise resolved }) .catch((error) => {
  
      console.error(error);
  
  });
//How do you sort elements in descending order an array
function sortDescending(array) {
  var len = array.length;
  for (var i = 0; i < len - 1; i++) {
    for (var j = 0; j < len - 1 - i; j++) {
      if (array[j] < array[j + 1]) {
        // Swap elements
        var temp = array[j];
        array[j] = array[j + 1];
        array[j + 1] = temp;
      } }  }
  return array;}
// Example usage
var numbers = [5, 2, 8, 1, 9];
var sortedNumbers = sortDescending(numbers);
console.log(sortedNumbers); // Output: [9, 8, 5, 2, 1]

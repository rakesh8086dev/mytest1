 function fetchData(i) {
    return new Promise(function(resolve, reject) {
      setTimeout(function() {
        console.log("Data fetched!",i);
        resolve();
      }, i*1000);
    });
  }
  
  async function fetchDataAndHandle(n) {
    try {
        for(let i=0; i<=n;i++){
      await fetchData(i);
        }
    } catch (error) {
      console.error("Async/Await: Error:", error);
    }
  }
  
  fetchDataAndHandle(20);
let arr=[];
let obj={};
console.log(typeof arr);
console.log(typeof obj);
let temp1=1;


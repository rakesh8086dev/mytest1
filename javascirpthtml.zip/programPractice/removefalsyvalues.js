//How do you remove falsy values from an array

const array1 = [0, false, '', null, undefined, NaN, 42, 'Hello'];

const filteredArray = array1.filter(Boolean);

console.log(filteredArray);

//How do you get unique values of an array

const array = [1, 2, 3, 4, 2, 1, 3, 5];

const uniqueArray = [...new Set(array)];

console.log(uniqueArray);

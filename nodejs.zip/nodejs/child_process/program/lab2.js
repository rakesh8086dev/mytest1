const { spawn } = require('child_process');

// Example: Run the 'findstr' command to search for a string in a file on Windows
const searchString = 'example';
const filePath = 'E:\\mytutorial_2024\\nodejs\\child_process\\file.txt';

const childProcess = spawn('findstr', [searchString, filePath], { windowsHide: true, shell: true });

// Event listener for handling the output of the command (stdout)
childProcess.stdout.on('data', (data) => {
  console.log(`stdout: ${data}`);
});

// Event listener for handling the errors (stderr)
childProcess.stderr.on('data', (data) => {
  console.error(`stderr: ${data}`);
});

// Event listener for handling the exit of the command
childProcess.on('close', (code) => {
  console.log(`child process exited with code ${code}`);
});

// Provide input to the child process via stdin
const inputString = 'This is an example input.\n';
childProcess.stdin.write(inputString);
childProcess.stdin.end();

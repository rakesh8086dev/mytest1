const { spawn } = require('child_process');

// Example: Run the 'dir' command to list files in the current directory on Windows
const childProcess = spawn('cmd.exe', ['/c', 'dir'], { windowsHide: true });

// Event listener for handling the output of the command (stdout)
childProcess.stdout.on('data', (data) => {
  console.log(`stdout: ${data}`);
});

// Event listener for handling the errors (stderr)
childProcess.stderr.on('data', (data) => {
  console.error(`stderr: ${data}`);
});

// Event listener for handling the exit of the command
childProcess.on('close', (code) => {
  console.log(`child process exited with code ${code}`);
});

// You can also send data to the child process via stdin
// Uncomment the following lines to send data to the child process
/*
childProcess.stdin.write('Input to the child process\n');
childProcess.stdin.end();
*/

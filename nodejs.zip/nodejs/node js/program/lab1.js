function immediateFunction() {
    console.log('Immediate function executed');
}

function timeoutFunction() {
    console.log('Timeout function executed');
}

function nextTickFunction() {
    console.log('NextTick function executed');
}

// Using process.nextTick
process.nextTick(nextTickFunction);

// Using setTimeout
setTimeout(timeoutFunction, 0);

// Using setImmediate
setImmediate(immediateFunction);

console.log('Main thread continues...');

// Output order may vary, but "NextTick function executed" will always come before the other two


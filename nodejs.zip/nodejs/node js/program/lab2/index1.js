let salt = bcrypt.genSaltSync(10)
			var hash = bcrypt.hashSync(body.newpassword, salt)
			body.newpassword = hash;
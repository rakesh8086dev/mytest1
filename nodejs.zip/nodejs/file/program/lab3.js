const fs = require('fs');
fs.open('myfile.txt', 'w', (err, fd) => {
  if (err) throw err;
const data = 'Hello, world!';
  const buffer = Buffer.from(data, 'utf8');
  const offset = 0;
  const length = buffer.length;
  const position = null; 
	  // Write the data to the file
  fs.write(fd, buffer, offset, length, position, (err, bytesWritten, buffer) => {
    if (err) throw err;
console.log(`${bytesWritten} bytes written.`);
    // Close the file
    fs.close(fd, (err) => {
      if (err) throw err;
      console.log('File closed.'); });});});

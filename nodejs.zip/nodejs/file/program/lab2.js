const fs = require('fs');

const filePath = 'file.txt';

fs.stat(filePath, (err, stats) => {
  if (err) {
    console.error(err);
    return;
  }

  console.log('File information:');
  console.log(`- Size: ${stats.size} bytes`);
  console.log(`- Created: ${stats.birthtime}`);
  console.log(`- Modified: ${stats.mtime}`);
  console.log(`- Is File: ${stats.isFile()}`);
  console.log(`- Is Directory: ${stats.isDirectory()}`);
});

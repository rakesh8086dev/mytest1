const fs = require('fs');

fs.open('file.txt', 'r', (err, fd) => {
  if (err) {
    console.error(err);
    return;
  }

  // File opened successfully
  console.log('File opened successfully.');

  // Do something with the file descriptor (fd)

  // Close the file after performing operations
  fs.close(fd, (err) => {
    if (err) {
      console.error(err);
      return;
    }
    console.log('File closed successfully.');
  });
});

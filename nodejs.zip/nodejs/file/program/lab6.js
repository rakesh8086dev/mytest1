const fs = require('fs');

const filePath = 'myfile.txt';
const dataToAppend = 'This data will be appended to the file.';

fs.appendFile(filePath, dataToAppend, (err) => {
  if (err) {
    console.error('An error occurred while appending to the file:', err);
  } else {
    console.log('Data was appended to the file successfully.');
  }
});

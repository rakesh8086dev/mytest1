const fs = require('fs');
const path = './delete.txt';
fs.unlink(path, (error) => {
  if (error) {
    // Handle the error
    console.error(error);
    return;
  }

  // File was successfully deleted
  console.log('File deleted');
});

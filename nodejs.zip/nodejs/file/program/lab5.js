const fs = require('fs');

const oldPath = './myfile.txt';
const newPath = './newfile.txt';

fs.rename(oldPath, newPath, (err) => {
  if (err) {
    console.error(err);
    return;
  }
  console.log('File renamed successfully.');
});

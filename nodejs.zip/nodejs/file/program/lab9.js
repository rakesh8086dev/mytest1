const fs = require("fs/promises");

(async () => {
  const watcher = fs.watch("./file.txt");

  for await (const event of watcher) {
    if (event.eventType === "change") {
      // The file was changed...
      console.log(event);
    }
  }
})();
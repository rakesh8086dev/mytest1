// Import required modules
const express = require('express');
const mysql = require('mysql2');

// Create an Express app
const app = express();

// Create a MySQL connection pool
const pool = mysql.createPool({
  host: 'your_mysql_host',
  user: 'your_mysql_user',
  password: 'your_mysql_password',
  database: 'your_mysql_database',
  connectionLimit: 10, // Adjust this based on your needs
});

pool.connect((err => {
  if (err) throw err;
  console.log('MySQL Connected');
}));

// Middleware to parse JSON requests
app.use(express.json());

// Example route to execute a MySQL query
app.get('/example', (req, res) => {
  // Replace the query with your own
  const query = 'SELECT * FROM your_table';

  // Use the pool to query the database
  pool.query(query, (error, results, fields) => {
    if (error) {
      console.error(error);
      res.status(500).send('Internal Server Error');
    } else {
      res.json(results);
    }
  });
});

// Start the Express server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

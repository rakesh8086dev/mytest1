module.exports = {
  key: process.env.APP_KEY,
  env: process.env.APP_ENV,
  port: process.env.APP_PORT,
  api_endpoint: process.env.API_ENDPOINT,
};

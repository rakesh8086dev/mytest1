const mongoose = require('mongoose');

const collectivesSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'title name is required'],
      trim: true
    },
    profileImage: {
      type: String,
      required: [true, 'collectives profile image is required'],
      trim: true
    },
    bannerImage: {
        type: String,
        required: [true, 'collectives banner image is required'],
        trim: true
    },
    descriptions: {
      type: String,
      required: [true, 'descriptions is required'],
    },
    preference: 
        {
            cryptoAsset: {
            type: Boolean,
            required: [true, 'crypto asset is required'],
            default: false
          },
          subscribersRequerst: {
            type: Boolean,
            required: [true, 'subscribers requerst is required'],
            default: false
          },
          criteriaToJoin: {
            type: Boolean,
            required: [true, 'criteria to join is required'],
            default: false
          },
          displayFollowers: {
            type: Boolean,
            required: [true, 'display followers is required'],
            default: false
          },
          markAsFeatured: {
            type: Boolean,
            required: [true, 'mark_as_featured is required'],
            default: false
          },
          banner: {
            type: Boolean,
            required: [true, 'banner is required'],
            default: false
          },
          displayPriceChart: {
            type: Boolean,
            required: [true, 'display price chart is required'],
            default: false
          },
          displayBuyNow: {
            type: Boolean,
            required: [true, 'display buy now is required'],
            default: false
          }
        },
        tags: {
            type: [],
            required: [true, 'tags is required'],
          },   
          seoKewords: {
            type: [],
            required: [true, 'seo kewords is required'],
          }, 
          createdBy: {
            type: String,
            required: [true, 'createdBy name is required'],
            trim: true
          },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

collectivesSchema.index({ createdBy: 1 });


module.exports = mongoose.model('collectives', collectivesSchema);

const ERROR_MESSAGES = require('../utils/errorMessage.util');
const Collectives = require('../models/collectives.model');

async function createCollective(payload) {
  try {
     const preferenceData = {
      cryptoAsset: payload.cryptoAsset,
      subscribersRequerst: payload.subscribersRequerst,
      criteriaToJoin: payload.criteriaToJoin,
      displayFollowers: payload.displayFollowers,
      markAsFeatured: payload.markAsFeatured,
      banner: payload.banner,
      displayPriceChart: payload.displayPriceChart,
      displayBuyNow: payload.displayBuyNow,
     }
    const collectiveData = {
      title: payload.title,
      image: payload.profileImage,
      descriptions: payload.descriptions,
      preference: preferenceData,
      tags:payload.tags,
      seoKewords: payload.seo_kewords,
      createdBy: payload.createdBy,
    };

    const collectives = await Collectives.create(collectiveData);
  
    return { chatId: collectives._id };
 

  } catch (error) {
    console.error('Error in createCollective:', error);
    throw error;
  }
}

async function getCollectiveById(collectiveId) {
  return;
}

async function getCollectiveByName(name) {
  return;
}

module.exports = {
  createCollective,
  getCollectiveById,
  getCollectiveByName,
};

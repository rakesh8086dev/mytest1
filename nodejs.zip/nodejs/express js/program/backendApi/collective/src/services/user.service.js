const ERROR_MESSAGES = require('../utils/errorMessage.util');

async function createUser(user) {
  return;
}

async function updateUser(user) {
  return;
}

async function getUserById(userId) {
  return;
}

async function getUserByEmail(email) {
  return;
}

module.exports = {
  createUser,
  updateUser,
  getUserById,
  getUserByEmail,
};

const ERROR_MESSAGES = require('../utils/errorMessage.util');

async function register(data) {
  return;
}

async function remove(userId) {
  return;
}

async function disable(userId) {
  return;
}

module.exports = {
  register,
  remove,
  disable,
};

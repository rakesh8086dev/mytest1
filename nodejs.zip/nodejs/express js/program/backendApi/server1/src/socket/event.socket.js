module.exports = {
  JOIN: 'join',
  TYPING: 'typing',
  DISCONNECT: 'disconnect',
  STOP_TYPING: 'stopTyping',
  CHAT_UPDATE: 'chat:update',
};

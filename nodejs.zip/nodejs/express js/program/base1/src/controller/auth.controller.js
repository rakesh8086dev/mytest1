const userService= require('../service/auth.service')

async function register(req, res) {
    const payload = req.body;
    try {
      const user = await userService.register(payload);
        return res.status(200).json({
            success: true,
            data: user,
          });
    } catch (error) {
        return res.status(401).json({
            success: false,
            data: "error",
          });
    }
  }
  async function login(req, res) {
    const payload = req.body;
    try {
      const user = await userService.login(payload);
        return res.status(200).json({
            success: true,
            data: user,
          });
    } catch (error) {
        return res.status(401).json({
            success: false,
            data: "error",
          });
    }
  }

  module.exports = {
    register,login
  };
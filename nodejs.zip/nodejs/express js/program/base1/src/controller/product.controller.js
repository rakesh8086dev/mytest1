const productService= require('../service/product.service')

async function addProduct(req, res) {
    const payload = req.body;
    try {
      const user = await productService.addProduct(payload);
        return res.status(200).json({
            success: true,
            data: user,
          });
    } catch (error) {
        return res.status(401).json({
            success: false,
            data: error,
          });
    }
  }

  module.exports={
    addProduct
  }
const express = require('express');
const db = require('./db.config');
const logmiddlware = require('./middlewares/log.middleware');
const auth = require('./middlewares/auth.middleware');
const AuthController = require('./controller/auth.controller');
const ProductController = require('./controller/product.controller');

const app = express();

// Express automatically parses JSON and URL-encoded data
app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded

// db connection.
db.establishConnection();

// Register middleware globally
app.use(logmiddlware.apiCallLog);

// Route handler
app.get('/', (req, res) => {
  res.send('Hello, World!');
});
app.post('/register',AuthController.register);
app.post('/login',AuthController.login);
app.post('/addproduct',[auth],ProductController.addProduct)

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

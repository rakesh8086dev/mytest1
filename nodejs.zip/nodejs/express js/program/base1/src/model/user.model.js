const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'name is required'],
      trim: true
    },
    email: {
      type: String,
      required: [true, 'email is required'],
      trim: true
    },
    address: {
        type: String,
        required: [true, 'address is required'],
        trim: true
    },
    password: {
      type: String,
      required: [true, 'password is required'],
    },
    createdBy: {
        type: String,
        required: [true, 'createdBy is required'],
      },
      updatedBy: {
        type: String,
        default:null
      }
},
  {
    timestamps: true,
    versionKey: false,
  }
);

userSchema.index({ createdBy: 1 });


module.exports = mongoose.model('user', userSchema);

const mongoose = require('mongoose');

const productSchema = new mongoose.Schema(
  {
    productName: {
      type: String,
      required: [true, 'productName is required'],
      trim: true
    },
    image: {
      type: String,
      required: [true, 'image is required'],
      trim: true
    },
    productType: {
        type: String,
        required: [true, 'address is required'],
        trim: true
    },
    createdBy: {
        type: String,
        required: [true, 'createdBy is required'],
      },
      updatedBy: {
        type: String,
        default:null
      }
},
  {
    timestamps: true,
    versionKey: false,
  }
);

productSchema.index({ createdBy: 1 });


module.exports = mongoose.model('product', productSchema);

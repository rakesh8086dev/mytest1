const Product= require('../model/product.model');


async function addProduct(productData) {
    try{
    const product = await Product.create(productData);
    return {product: product };
    }catch(error){
        console.error('Error in Product:', error);
        throw error;
    }
   
}




module.exports = {
    addProduct
}
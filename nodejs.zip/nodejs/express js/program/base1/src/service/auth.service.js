const User= require('../model/user.model');
const jwt = require('jsonwebtoken');
const secretKey = "abcd";

async function register(userData) {
    const user = await User.create(userData);
    const token = jwt.sign({ userId: user.id, username: user.name }, secretKey, { expiresIn: '1h' });
    return {token: token };
}

async function login(userData) {
    const { name, password } = userData;

    // Mock user authentication (replace with your actual authentication logic)
    const user = await User.find({ name: name , password:password });
       console.log("user",user);
    if (user) {
      // Create a JWT token
      const token = jwt.sign({ userId: user.id, username: user.name }, secretKey, { expiresIn: '1h' });
  
    return {token: token };
    // Send the token as a response
  
  } else {
    return { message: 'Invalid credentials' };
  }
}


module.exports = {
    register,login
}
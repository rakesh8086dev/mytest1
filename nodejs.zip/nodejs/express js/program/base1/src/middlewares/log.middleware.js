// Example middleware function
const apiCallLog = (req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next(); // Call the next middleware in the chain
  };


  module.exports = {
    apiCallLog
  };
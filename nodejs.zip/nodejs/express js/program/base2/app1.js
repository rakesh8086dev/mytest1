const express = require('express');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');

const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const RATE_LIMIT_MAX_REQUESTS = 100; // Max number of requests per window

const limiter = rateLimit({
  windowMs: RATE_LIMIT_WINDOW_MS,
  max: RATE_LIMIT_MAX_REQUESTS,
  message: { error: 'Please try again later.' },
  headers: true, // Enables X-RateLimit headers
});

const app = express();
  app.disable('x-powered-by');// hide information about server technology and version
  app.use(helmet()); // enhance the security of web applications by setting various HTTP headers. 
  app.use(cors()); // restricted resources on another domain
  app.use(limiter);
  app.use(express.json({ limit: '5mb' }));

// In a real application, you would store these in a secure way (e.g., environment variables)
const secretKey = 'your-secret-key';
const refreshTokenSecret = 'your-refresh-token-secret';
const accessTokenExpirationTime = '15m';
const refreshTokenExpirationTime = '7d';
let refreshTokens = [];
// Middleware to verify the access token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);
  jwt.verify(token, secretKey, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};
// Define a Mongoose schema
const personSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  age: Number,
  password:String
});

// Create a Mongoose model based on the schema
const Person = mongoose.model('Person', personSchema);

app.post('/register', async(req,res)=>{
  
  try{
    const persondata = {
      firstName: "rakesh",
    lastName: "kumar",
    age: 32,
    password:"123"
    }
    const getperson = await Person.create(persondata);
    const query = 'INSERT INTO student (name, address, phone) VALUES ("rakesh","address", 32123)';
  pool.query(query, (error, results) => {
      if (error) {
        console.error('Error executing query:', error);
        return res.status(500).send('Internal Server Error');
      }
      res.status(200).json({
        status:true,
        data:{getperson,...results}
     })
    });

    
    }catch(error){
        console.error('Error in Product:', error);
        throw error;
    }
})
// Endpoint to generate an access token and a refresh token
app.post('/login', async(req, res) => {
  const {firstName,pawword} = req.body;

  const user = await Person.findOne({ firstName: "rakesh" , password:"123" });
     console.log("user",user);
     const payload = {
        id : user._id,
        name: user.name
     }
  const accessToken = jwt.sign(payload, secretKey, { expiresIn: accessTokenExpirationTime });
  const refreshToken = jwt.sign(payload, refreshTokenSecret, { expiresIn: refreshTokenExpirationTime });

  refreshTokens.push(refreshToken);

  res.json({ accessToken, refreshToken });
});

// Endpoint to refresh the access token using a valid refresh token
app.post('/token', (req, res) => {
  const refreshToken = req.body.refreshToken;
  if (!refreshToken) return res.sendStatus(401);

  if (!refreshTokens.includes(refreshToken)) return res.sendStatus(403);

  jwt.verify(refreshToken, refreshTokenSecret, (err, user) => {
    if (err) return res.sendStatus(403);

    const accessToken = jwt.sign({ username: user.username }, secretKey, { expiresIn: accessTokenExpirationTime });
    res.json({ accessToken });
  });
});

// Endpoint to logout and invalidate a refresh token
app.post('/logout', (req, res) => {
  const refreshToken = req.body.refreshToken;
  refreshTokens = refreshTokens.filter(token => token !== refreshToken);
  res.sendStatus(204);
});

// Protected endpoint that requires a valid access token
app.get('/list', authenticateToken, async(req, res) => {
  const user = await Person.find();
  res.json({ status: true,
  data: user});
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

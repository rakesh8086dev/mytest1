const resources = [];

const getOne = (req, res) => {
  const resourceId = req.params.id;
  const resource = resources.find(r => r.id === resourceId);
  if (!resource) {
    return res.sendStatus(404);
  }
  res.json(resource);
};

const createOne = (req, res) => {
  const newResource = req.body;
  resources.push(newResource);
  res.status(201).json(newResource);
};

const updateOne = (req, res) => {
  const resourceId = req.params.id;
  const updatedProperties = req.body;
  const indexToUpdate = resources.findIndex(obj => obj.id === resourceId);

  // Check if the object with the specified id was found
  if (indexToUpdate !== -1) {
    // Update the object with the specified id
    resources[indexToUpdate] = { ...resources[indexToUpdate], ...updatedProperties };
    res.status(201).json({"msg":`Object with id ${resourceId} updated:`});
   
  } else {
    res.status(201).json({"msg":`Object with id ${resourceId} not found.`});
  }
};

const deleteOne = (req, res) => {
  const resourceId = req.params.id;
  arrayOfObjects = resources.filter(obj => obj.id !== resourceId);
  res.status(201).json({"msg":arrayOfObjects});
};

module.exports = {
  getOne,
  createOne,
  updateOne,
  deleteOne,
};
const express = require('express');
const resourceController = require('./resource.controller');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/api/resource/:id', resourceController.getOne);
app.post('/api/resource', resourceController.createOne);
app.put('/api/resource/:id', resourceController.updateOne);
app.delete('/api/resource/:id', resourceController.deleteOne);

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
const EventEmitter = require('events');

class PubSub extends EventEmitter {
  publish(topic, message) {
    console.log(`Publishing message on topic "${topic}": ${message}`);
    this.emit(topic, message);
  }

  subscribe(topic, listener) {
    console.log(`Subscribing to topic "${topic}"`);
    this.on(topic, listener);
  }

  unsubscribe(topic, listener) {
    console.log(`Unsubscribing from topic "${topic}"`);
    this.removeListener(topic, listener);
  }
}

// Create an instance of PubSub
const pubSub = new PubSub();

// Subscriber 1
const subscriber1 = (message) => {
  console.log(`Subscriber 1 received message: ${message}`);
};

// Subscriber 2
const subscriber2 = (message) => {
  console.log(`Subscriber 2 received message: ${message}`);
};

// Subscribe subscribers to topics
pubSub.subscribe('news', subscriber1);
pubSub.subscribe('news', subscriber2);
pubSub.subscribe('sports', subscriber1);

// Publish messages on topics
pubSub.publish('news', 'Breaking news: Important announcement!');
pubSub.publish('sports', 'Goal! Team scores.');

// Unsubscribe a subscriber from a topic
pubSub.unsubscribe('news', subscriber1);

// Publish a message again (subscriber1 for 'news' should not receive it)
pubSub.publish('news', 'More news coming in...');

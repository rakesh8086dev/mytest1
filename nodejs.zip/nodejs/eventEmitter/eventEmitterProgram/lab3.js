const EventEmitter = require("events"); // or include ./events.js to use the custom implementation
const myEmitter = new EventEmitter();

function c1() {
   console.log('an event occurred!');
}

function c2() {
   console.log('yet another event occurred!');
}

myEmitter.on('eventOne', c1); // Register for eventOne
myEmitter.on('eventOne', c2); // Register for eventOne

// register event once
myEmitter.once('eventOnce', () => console.log('eventOnce once fired'));

//Registering for the event with callback parameters
myEmitter.on('status', (code, msg)=> console.log(`Got ${code} and ${msg}`));

//Unregistering events
myEmitter.off('eventOne', c1);



//Getting Listener count
console.log(myEmitter.listenerCount('eventOne'));

//Getting Raw Listeners
console.log(myEmitter.rawListeners('eventOne'));
myEmitter.emit("eventOne")
myEmitter.emit("eventOnce")
myEmitter.emit('status', 200, 'ok');


// Async Example demo
class WithTime extends EventEmitter {
    execute(asyncFunc, ...args) {
      this.emit('begin');
      console.time('execute');
      this.on('data', (data)=> console.log('got data ', data));
      asyncFunc(...args, (err, data) => {
        if (err) {
          return this.emit('error', err);
        }
        this.emit('data', data);
        console.timeEnd('execute');
        this.emit('end');
      });
    }
  }


  const withTime = new WithTime();

withTime.on('begin', () => console.log('About to execute'));
withTime.on('end', () => console.log('Done with execute'));

const readFile = (url, cb) => {
  fetch(url)
    .then((resp) => resp.json()) // Transform the data into json
    .then(function(data) {
      cb(null, data);
    });
}

withTime.execute(readFile, 'https://jsonplaceholder.typicode.com/posts/1');
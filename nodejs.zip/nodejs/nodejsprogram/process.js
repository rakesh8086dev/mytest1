
const fs = require('fs');
console.log('Start');

setTimeout(() => {
console.log('Set Timeout - 1');

Promise.resolve().then(() => {
console.log('Promise - 1');
}).then(() => {
console.log('Promise - 2');
});

}, 0);

setImmediate(() => {
console.log('Set Immediate');
});

process.nextTick(() => {
console.log('Next Tick');
// It's like an infinite loop point for microtask queue
process.nextTick(() => console.log('Next Tick - nested'));
});

fs.readFile("myfile.txt", 'utf-8', (err, data) => {
if (err) throw err;
console.log('File Read');
});

console.log('End');
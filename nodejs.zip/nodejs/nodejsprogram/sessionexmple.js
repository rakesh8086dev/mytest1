const express = require('express');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);

const app = express();
const store = new MongoDBStore({
uri: 'mongodb://127.0.0.1:27017/sessiontest',
collection: 'mySessions',
});

app.use(session({
secret: 'mySecret',
resave: false,
saveUninitialized: true,
store: store,
}));

app.listen(3000, () => {
console.log('Server running on port 3000');
});
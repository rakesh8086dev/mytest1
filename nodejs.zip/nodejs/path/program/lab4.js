const path = require('path');

const directory = path.dirname('/path/to/file.txt');
console.log("directory",directory);
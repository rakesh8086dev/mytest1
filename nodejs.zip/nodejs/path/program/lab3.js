const path = require('path');

const filename = path.basename('/path/to/file.txt');
console.log("filename",filename);
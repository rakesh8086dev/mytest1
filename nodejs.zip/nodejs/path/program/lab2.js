const path = require('path');

const absolutePath = path.resolve('folder', 'file.txt');
console.log("absolutePath",absolutePath);
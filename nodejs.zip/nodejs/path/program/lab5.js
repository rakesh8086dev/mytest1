const path = require('path');

const extension = path.extname('/path/to/file.txt');
console.log("extension",extension);